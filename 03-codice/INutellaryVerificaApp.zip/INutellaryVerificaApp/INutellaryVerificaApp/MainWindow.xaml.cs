﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System;
using PgpCore;
using System.IO;
using System.Threading.Tasks;

namespace INutellaryVerificaApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        static string basePath = @"C:\Users\Utente\Desktop\INutellaryVerificaApp\DemoFiles\";

        private async void BtnVerifica_Click(object sender, RoutedEventArgs e)
        {
            // Load keys
            FileInfo publicKey = new FileInfo(basePath + "openSUSE-Leap-15.3-3-NET-x86_64-Build38.1-Media.iso.sha256.asc");
            EncryptionKeys encryptionKeys = new EncryptionKeys(publicKey);

            // Reference input
            FileInfo inputFile = new FileInfo(basePath + "just-a-signed-file.gpg");

            // Verify
            PGP pgp = new PGP(encryptionKeys);
            bool verified = await pgp.VerifyFileAsync(inputFile);

            if (verified == true)
            {
                TxtRisultato.Text =  "The content is signed with the given public key";
            }
            else
            {
                TxtRisultato.Text = "WARNING The content is NOT signed with the given public key";
            }
        }

        private void BtnAsc_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnPgp_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
