﻿using System.Collections.Generic;
using System.Security;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System;
using PgpCore;
using System.IO;
using System.Threading.Tasks;
using System.Security.Cryptography;
using Microsoft.Win32;

namespace INutellaryVerificaApp
{
    public partial class MainWindow : Window
    {

        public MainWindow()
        {
            InitializeComponent();
        }

        string AscPath;
        string ShaPath;
        string Chiave;
        string NewKey;

        private void BtnAsc_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ApriAsc = new();
            if (ApriAsc.ShowDialog() == true)
            {
               AscPath = ApriAsc.FileName;
            }

            TxtAsc.Text = AscPath;
        }

        private void BtnSha_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ApriFile = new();
            if(ApriFile.ShowDialog() == true)
            {
                ShaPath = ApriFile.FileName;

                using (SHA256 sha256Hash = SHA256.Create())
                {
                    string hash = GetHash(sha256Hash, ShaPath);

                    TxtSha.Text = hash;
                }
            }
        }

        private async void BtnVerifica_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog ApriPgp = new();
            ApriPgp.Filter = "file pgp (*.gpg)|*.gpg|All files (*.*)|*.*";
            if (ApriPgp.ShowDialog() == true)
            {
                NewKey = ApriPgp.FileName;
            }

            Chiave = TxtPgp.Text;
            NewKey = Chiave.Replace(" ", "");

            /*    using (FileStream flusso = new FileStream("dati.gpg", FileMode.OpenOrCreate, FileAccess.Write))
            {
                StreamWriter scrittore = new StreamWriter(flusso);
                string contenuto = TxtPgp.Text;
                scrittore.WriteLine(contenuto);
                scrittore.Flush();
            }*/

            // Load keys
            FileInfo publicKey = new FileInfo(AscPath);
            EncryptionKeys encryptionKeys = new EncryptionKeys(publicKey);

            // Reference input
            FileInfo inputFile = new FileInfo(NewKey);

            // Verify
            PGP pgp = new PGP(encryptionKeys);
            bool verified = await pgp.VerifyFileAsync(inputFile);

            if (verified == true)
            {
                TxtRisultato.Text = "Il contenuto è verificato ed è originale";
            }
            else
            {
                TxtRisultato.Text = "ATTENZIONE! Il contenuto non è verificato ed è stato corrotto";
            }
        }

        private static string GetHash(HashAlgorithm hashAlgorithm, string input)
        {

            // Convert the input string to a byte array and compute the hash.
            byte[] data = hashAlgorithm.ComputeHash(Encoding.UTF8.GetBytes(input));

            // Create a new Stringbuilder to collect the bytes
            // and create a string.
            var sBuilder = new StringBuilder();

            // Loop through each byte of the hashed data
            // and format each one as a hexadecimal string.
            for (int i = 0; i < data.Length; i++)
            {
                sBuilder.Append(data[i].ToString("x2"));
            }

            // Return the hexadecimal string.
            return sBuilder.ToString();
        }

        
    }
}
