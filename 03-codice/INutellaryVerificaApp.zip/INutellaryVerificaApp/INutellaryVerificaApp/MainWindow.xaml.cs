﻿using System.Collections.Generic;
using System.Security;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System;
using PgpCore;
using System.IO;
using System.Threading.Tasks;
using System.Security.Cryptography;
using Microsoft.Win32;

namespace INutellaryVerificaApp
{
    public partial class MainWindow : Window
    {

        public MainWindow()
        {
            InitializeComponent();
        }

        string AscPath;
        string ShaPath;
        string sha;
        string Chiave;
        string NewKey;
        string file;

        private void BtnAsc_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ApriAsc = new();
            if (ApriAsc.ShowDialog() == true)
            {
               AscPath = ApriAsc.FileName;
            }

            TxtAsc.Text = AscPath;
        }

        private void BtnSha_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ApriFile = new();

            if (ApriFile.ShowDialog() == true)
            {
                ShaPath = ApriFile.FileName;
            }

            sha = GetHash(ShaPath);
            
        }

        private async void BtnVerifica_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog ApriPgp = new();
            ApriPgp.Filter = "file pgp (*.gpg)|*.gpg|Tutti i file (*.*)|*.*";
            if (ApriPgp.ShowDialog() == true)
            {
                NewKey = ApriPgp.FileName;
            }

            Chiave = TxtPgp.Text;
            NewKey = Chiave.Replace(" ", "");

            // Load keys
            FileInfo publicKey = new FileInfo(AscPath);
            EncryptionKeys encryptionKeys = new EncryptionKeys(publicKey);

            // Reference input
            FileInfo inputFile = new FileInfo(NewKey);

            // Verify
            PGP pgp = new PGP(encryptionKeys);
            bool verified = await pgp.VerifyFileAsync(inputFile);

            if (verified == true)
            {
                TxtRisultato.Text = "Il contenuto è verificato ed è originale";
            }
            else
            {
                TxtRisultato.Text = "ATTENZIONE! Il contenuto non è verificato ed è stato corrotto";
            }
        }

        static string GetHash(string ShaPath)
        {
            using SHA256 sha256 = SHA256.Create();

            foreach (string file in Directory.EnumerateFiles(ShaPath, "*.iso"))
            {
                string contents = File.ReadAllText(file);
            }

            sha256.ComputeHash(Encoding.UTF8.GetBytes(ShaPath));

            /*var sb = new StringBuilder();
            for (int i = 0; i < bytes.Length; i++)
            {
                sb.Append(bytes[i].ToString("x2"));
            }*/


        }
    }
}


