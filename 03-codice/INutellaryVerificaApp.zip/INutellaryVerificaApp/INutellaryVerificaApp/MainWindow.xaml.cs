﻿using System.Collections.Generic;
using System.Security;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System;
using PgpCore;
using System.IO;
using System.Threading.Tasks;
using System.Security.Cryptography;
using Microsoft.Win32;

namespace INutellaryVerificaApp
{
    public partial class MainWindow : Window
    {

        public MainWindow()
        {
            InitializeComponent();
        }

        string AscPath;
        string ShaPath;
        string Chiave;
        string NewKey;
        string FileIso;

        private void BtnAsc_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ApriAsc = new();
            if (ApriAsc.ShowDialog() == true)
            {
               AscPath = ApriAsc.FileName;
            }

            TxtAsc.Text = AscPath;
        }

        private void BtnSha_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ApriFile = new();

            if (ApriFile.ShowDialog() == true)
            {
                ShaPath = ApriFile.FileName;



                using (FileStream flusso = new FileStream(ShaPath, FileMode.Open, FileAccess.Read))
                {
                    StreamReader reader = new StreamReader(flusso);

                    byte contenuto;
                    while (!reader.EndOfStream)
                    {
                        byte linea = reader.ReadLine();
                        contenuto += linea + "\n";
                    }

                    FileIso = string(contenuto);

                    using (SHA256 sha256Hash = SHA256.Create())
                    {
                        string hash = GetHash(FileIso);

                        TxtSha.Text = hash;
                    }
                }
            }
        }

        private async void BtnVerifica_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog ApriPgp = new();
            ApriPgp.Filter = "file pgp (*.gpg)|*.gpg|All files (*.*)|*.*";
            if (ApriPgp.ShowDialog() == true)
            {
                NewKey = ApriPgp.FileName;
            }

            Chiave = TxtPgp.Text;
            NewKey = Chiave.Replace(" ", "");

            // Load keys
            FileInfo publicKey = new FileInfo(AscPath);
            EncryptionKeys encryptionKeys = new EncryptionKeys(publicKey);

            // Reference input
            FileInfo inputFile = new FileInfo(NewKey);

            // Verify
            PGP pgp = new PGP(encryptionKeys);
            bool verified = await pgp.VerifyFileAsync(inputFile);

            if (verified == true)
            {
                TxtRisultato.Text = "Il contenuto è verificato ed è originale";
            }
            else
            {
                TxtRisultato.Text = "ATTENZIONE! Il contenuto non è verificato ed è stato corrotto";
            }
        }

        static string GetHash(string shaPath)
        {
            // Create a SHA256   
            using (SHA256 sha256Hash = SHA256.Create())
            {
                // ComputeHash - returns byte array  
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(shaPath));

                // Convert byte array to a string   
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }
    }
}
