﻿using System;
using PgpCore;
using System.IO;
using System.Threading.Tasks;

namespace INutellaryVerificaApp
{
    class Programma
    {
        static string basePath = @"C:\Users\Utente\Desktop\INutellaryVerificaApp\DemoFiles\";

        static void Main(string[] args)
        {

            Console.WriteLine("Pgp Core Demo App");

            Task<string> messaggio;

            messaggio = Verifica();

            Console.WriteLine(messaggio.Result);
        }

        public static async Task<string> Verifica()
        {
            // Load keys
            FileInfo publicKey = new FileInfo(basePath + "public.asc");
            EncryptionKeys encryptionKeys = new EncryptionKeys(publicKey);

            // Reference input
            FileInfo inputFile = new FileInfo(basePath + "just-a-signed-file.pgp");

            // Verify
            PGP pgp = new PGP(encryptionKeys);
            bool verified = await pgp.VerifyFileAsync(inputFile);

            if (verified)
            {
                return "The content is signed with the given public key";
            }
            else
            {
                return "WARNING The content is NOT signed with the given public key";
            }
        }
    }
}
